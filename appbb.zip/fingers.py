#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Détection de doigts avec MediaPipe (à exécuter dans le venv mediapipe).
# Règles:
# - 5 doigts (au moins une main): envoyer la dernière photo du dossier media sur Discord
# - 3 doigts (au moins une main): shutdown immédiat
#
# Variables d'environnement utilisées (injectées par main.py):
# - DISCORD_WEBHOOK_URL : webhook Discord
# - MEDIA_DIR           : chemin du dossier media (photos/vidéos)

import os, sys, time, subprocess as sp
from pathlib import Path

import cv2
import mediapipe as mp
import requests

WEBHOOK = os.environ.get("DISCORD_WEBHOOK_URL", "")
MEDIA_DIR = Path(os.environ.get("MEDIA_DIR") or "media").resolve()

print("code fingerssss")

def send_discord_text(msg: str):
    if not WEBHOOK: 
        return
    try:
        requests.post(WEBHOOK, json={"content": msg}, timeout=5)
    except Exception:
        pass

def send_discord_file(path: Path, caption=""):
    if not WEBHOOK or not path.exists(): 
        return
    try:
        with path.open("rb") as f:
            files = {"file": (path.name, f)}
            data = {"content": caption}
            requests.post(WEBHOOK, data=data, files=files, timeout=15)
    except Exception:
        pass

def latest_photo_in_media():
    if not MEDIA_DIR.exists():
        return None
    pics = []
    for ext in ("*.jpg","*.jpeg","*.png"):
        pics += list(MEDIA_DIR.glob(ext))
    if not pics:
        return None
    return max(pics, key=lambda p: p.stat().st_mtime)

def shutdown():
    send_discord_text("⚠️ Commande: SHUTDOWN envoyée.")
    try:
        sp.Popen(["sudo", "shutdown", "-h", "now"])
    except Exception:
        pass

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=2,
                       min_detection_confidence=0.7,
                       min_tracking_confidence=0.7)

cap = cv2.VideoCapture(0)
start = time.time()
timeout = 30  # sécurité: ne pas boucler indéfiniment

def count_fingers(lm, hand_label):
    # index, middle, ring, pinky
    count = 0
    for tip_idx, pip_idx in [(8,6),(12,10),(16,14),(20,18)]:
        if lm[tip_idx].y < lm[pip_idx].y:
            count += 1
    # thumb
    if hand_label == "Right":
        if lm[4].x > lm[3].x: count += 1
    else:
        if lm[4].x < lm[3].x: count += 1
    return count

action_done = False

while cap.isOpened() and (time.time() - start) < timeout and not action_done:
    success, img = cap.read()
    if not success:
        break
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = hands.process(img_rgb)

    if results.multi_hand_landmarks:
        for i, hand in enumerate(results.multi_hand_landmarks):
            label = results.multi_handedness[i].classification[0].label  # "Left"/"Right"
            cnt = count_fingers(hand.landmark, label)

            # 5 doigts -> envoyer dernière photo du dossier media
            if cnt == 5:
                lp = latest_photo_in_media()
                if lp:
                    send_discord_text("🖐 Détection 5 doigts -> envoi de la dernière photo.")
                    send_discord_file(lp, "Dernière photo:")
                else:
                    send_discord_text("🖐 Détection 5 doigts, mais aucune photo trouvée dans 'media'.")
                action_done = True
                break

            # 3 doigts -> shutdown
            if cnt == 3:
                send_discord_text("🤟 Détection 3 doigts -> shutdown.")
                shutdown()
                action_done = True
                break

cap.release()
sys.exit(0)
