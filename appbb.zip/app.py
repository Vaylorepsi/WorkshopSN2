#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Interface vitrine + accès caché, protection par code, contrôle caméra,
# détection PIR -> envoi Discord (silencieux, SANS PHOTO), gestion bouton physique.
#
# Actions bouton:
# - 1 clic: photo (si session déverrouillée)
# - 2 clics: reconnaissance de doigts (venv mediapipe) -> 5 doigts: envoi dernière photo Discord ; 3 doigts: shutdown
# - 3 clics: redémarrage du programme
# - Appui long (>=2s): démarre vidéo ; un clic normal suivant: arrête vidéo
#
# Web:
# - Page vitrine "/" -> accès caché à /verify
# - /verify -> saisie du code (code.txt)
# - /dashboard -> actions: Photo, Vidéo ON/OFF, Bip buzzer, Armer/Désarmer, Déconnexion
#
# Note:
# - Tous les bips automatiques (mouvement/appui long) sont supprimés.
#   Seul le bouton "Bip" de l'interface peut faire sonner le buzzer.
# - DEMANDE: ne pas envoyer la photo sur Discord depuis l’interface -> /photo AUCUN ENVOI.

import os, sys, time, threading, signal, subprocess as sp, datetime as dt
from pathlib import Path
from typing import Optional, List
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import requests

# ----- CONFIG -----
WEB_BIND = "0.0.0.0"
WEB_PORT = 5000
APP_SECRET = "change_this_for_prod"          # REMPLACEZ EN PROD
CODE_FILE = "code.txt"
MEDIA_DIR = Path("media")

# Mettez votre webhook dans une variable d'environnement pour éviter de le commiter en clair:
# export DISCORD_WEBHOOK_URL="https://discord.com/api/webhooks/...."
DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL", "")

# GPIO pins (BCM)
PIN_BTN = 17
PIN_PIR = 22
PIN_BUZ = 27

# Vidéo
FPS, WIDTH, HEIGHT = 20, 1280, 720
FOURCC = "XVID"
EXT_VIDEO = "avi"

# ----- FLAGS & ETAT -----
state_lock = threading.Lock()
rec_lock = threading.Lock()      # protège writer/recording
armed = True
recording = False
unlocked = False
last_photo_path: Optional[Path] = None
writer = None
cap = None

# Journal mémoire (pour /status)
events: List[str] = []

# PIR cooldown pour éviter le spam
PIR_COOLDOWN_S = 10
_last_pir_alert = 0.0

# ----- UTILS -----
def log_event(msg: str):
    ts = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    with state_lock:
        events.append(line)
        if len(events) > 500:
            del events[:-200]

def read_secret_code() -> Optional[str]:
    try:
        return Path(CODE_FILE).read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        return None

def send_discord_text(content: str):
    if not DISCORD_WEBHOOK_URL:
        return
    try:
        r = requests.post(DISCORD_WEBHOOK_URL, json={"content": content}, timeout=5)
        r.raise_for_status()
    except Exception as e:
        log_event(f"Discord text error: {e}")

def send_discord_file(path: Path, content: str = ""):
    if not DISCORD_WEBHOOK_URL:
        return
    if not path or not path.exists():
        send_discord_text(content or "Fichier introuvable.")
        return
    try:
        with path.open("rb") as f:
            files = {"file": (path.name, f)}
            data = {"content": content}
            r = requests.post(DISCORD_WEBHOOK_URL, data=data, files=files, timeout=15)
            r.raise_for_status()
    except Exception as e:
        log_event(f"Discord file error: {e}")

def latest_photo_in_media() -> Optional[Path]:
    if not MEDIA_DIR.exists():
        return None
    pics = []
    for ext in ("*.jpg", "*.jpeg", "*.png"):
        pics += list(MEDIA_DIR.glob(ext))
    if not pics:
        return None
    return max(pics, key=lambda p: p.stat().st_mtime)

# ----- HARDWARE (OpenCV + gpiozero) -----
def init_camera():
    global cap
    import cv2
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)
    cap.set(cv2.CAP_PROP_FPS, FPS)
    if not cap.isOpened():
        raise RuntimeError("Caméra non disponible")

def release_camera():
    global cap
    try:
        if cap is not None:
            cap.release()
    except Exception:
        pass

def take_photo() -> Optional[Path]:
    import cv2
    ok, frame = cap.read()
    if not ok:
        log_event("Erreur capture photo")
        return None
    MEDIA_DIR.mkdir(parents=True, exist_ok=True)
    path = MEDIA_DIR / f"photo_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
    cv2.imwrite(str(path), frame)
    with state_lock:
        global last_photo_path
        last_photo_path = path
    log_event(f"Photo: {path.name}")
    return path

def start_recording():
    global writer, recording
    import cv2
    with rec_lock:
        if recording:
            return
        MEDIA_DIR.mkdir(parents=True, exist_ok=True)
        path = MEDIA_DIR / f"video_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.{EXT_VIDEO}"
        fourcc = cv2.VideoWriter_fourcc(*FOURCC)
        w = cv2.VideoWriter(str(path), fourcc, FPS, (WIDTH, HEIGHT))
        if not w or not w.isOpened():
            log_event("Erreur ouverture VideoWriter")
            return
        writer = w
        recording = True
        log_event(f"REC ON: {path.name}")

def stop_recording():
    global writer, recording
    with rec_lock:
        if not recording:
            return
        try:
            if writer is not None:
                writer.release()
        except Exception:
            pass
        writer = None
        recording = False
        log_event("REC OFF")

# Buzzer & capteurs
try:
    from gpiozero import Button, Buzzer, MotionSensor
    btn = Button(PIN_BTN, pull_up=True, hold_time=2.0, bounce_time=0.05)
    buz = Buzzer(PIN_BUZ, active_high=True)
    pir = MotionSensor(PIN_PIR)
except Exception as e:
    log_event(f"GPIO init en mode MOCK: {e}")
    class _Mock:
        def __init__(self,*a,**k): pass
        def on(self): pass
        def off(self): pass
        def beep(self, *a, **k): pass
        @property
        def motion_detected(self): return False
    class _Btn(_Mock):
        is_held=False
        def when_held(self,*a,**k): pass
        def when_released(self,*a,**k): pass
        def when_pressed(self,*a,**k): pass
    btn, buz, pir = _Btn(), _Mock(), _Mock()

def buz_beep(pattern="short"):
    # Appelé uniquement depuis l'interface web.
    try:
        if pattern == "short":
            buz.on(); time.sleep(0.1); buz.off()
        elif pattern == "triple":
            for _ in range(3):
                buz.on(); time.sleep(0.1); buz.off(); time.sleep(0.1)
        elif pattern == "long":
            buz.on(); time.sleep(1.0); buz.off()
    except Exception:
        pass

# ----- PIR: détection mouvement (SANS BUZZER, SANS PHOTO) -----
def pir_watch_loop():
    global _last_pir_alert
    log_event("PIR watcher démarré")
    while True:
        try:
            if hasattr(pir, "motion_detected"):
                if pir.motion_detected and armed:
                    now = time.time()
                    if now - _last_pir_alert >= PIR_COOLDOWN_S:
                        _last_pir_alert = now
                        log_event("Mouvement détecté (PIR) [silencieux, message seulement]")
                        send_discord_text("🚨 Mouvement détecté (alarme armée).")
                    # aucun envoi de photo ici
            time.sleep(0.05)
        except Exception as e:
            log_event(f"PIR loop err: {e}")
            time.sleep(0.5)

# ----- Bouton physique: clics -----
_click_count = 0
_click_lock = threading.Lock()
_click_timer = None

def _handle_clicks():
    global _click_count
    with _click_lock:
        count = _click_count
        _reset_clicks()
    if not unlocked:
        log_event("Clic(s) ignoré(s) (session verrouillée)")
        return
    if count == 1:
        take_photo()
    elif count == 2:
        run_fingers_job()
    elif count == 3:
        log_event("Triple clic -> restart programme")
        os.execv(sys.executable, [sys.executable] + sys.argv)

def _reset_clicks():
    global _click_count, _click_timer
    _click_count = 0
    if _click_timer:
        _click_timer.cancel()
        _click_timer = None

def on_button_pressed():
    global _click_count, _click_timer
    # Si enregistrement lancé par appui long, un simple clic arrête
    with rec_lock:
        rec_now = recording
    if rec_now and unlocked:
        stop_recording()
        return
    with _click_lock:
        _click_count += 1
        if _click_timer is None:
            _click_timer = threading.Timer(0.35, _handle_clicks)
            _click_timer.start()

def on_button_held():
    if unlocked:
        start_recording()
    else:
        log_event("Appui long ignoré (verrouillé)")

def setup_button_callbacks():
    try:
        btn.when_pressed = on_button_pressed
        btn.when_held = on_button_held
    except Exception:
        pass

# ----- Reconnaissance doigts (script séparé dans venv) -----
def run_fingers_job():
    log_event("Reconnaissance doigts (double clic) ...")
    # IMPORTANT: activation du venv avant d'appeler fingers.py
    cmd = 'python3 appbb/fingers.py'
    try:
        env = os.environ.copy()
        env["DISCORD_WEBHOOK_URL"] = "https://discord.com/api/webhooks/1417881116760866846/wuQsvYkGI7-TGiUeFFbLG9WS-0q3y0JsSYA5mLLrO0BbAAIfGPuIWshr76KRycB39NLB"
        env["MEDIA_DIR"] = str(MEDIA_DIR.resolve())

        result = sp.run(["bash", "-lc", cmd], check=False, env=env)

        if result.returncode == 0:
            log_event("Reconnaissance doigts : succès ✅")
        else:
            log_event(f"Reconnaissance doigts : erreur (code {result.returncode}) ❌")

    except Exception as e:
        log_event(f"Erreur lancement fingers.py: {e}")

# ----- Camera writer loop -----
def cam_write_loop():
    import cv2
    log_event("Boucle caméra démarrée")
    while True:
        try:
            ok, frame = cap.read()
            if not ok:
                time.sleep(0.01); continue
            # prendre un snapshot du writer sous verrou pour éviter courses
            with rec_lock:
                w = writer
                rec = recording
            if rec and w is not None:
                w.write(frame)
            time.sleep(0.005)
        except Exception as e:
            log_event(f"Cam loop err: {e}")
            time.sleep(0.2)

# ----- Flask -----
app = Flask(__name__)
app.secret_key = APP_SECRET

def is_logged_in() -> bool:
    return session.get("unlocked", False) is True

@app.route("/")
def landing():
    return render_template("landing.html")

@app.route("/verify", methods=["GET", "POST"])
def verify():
    if request.method == "POST":
        entered = request.form.get("code", "").strip()
        secret = read_secret_code()
        if not secret:
            flash("Fichier code.txt introuvable.", "error")
            return redirect(url_for("verify"))
        if entered == secret:
            session["unlocked"] = True
            global unlocked
            unlocked = True
            flash("Accès accordé.", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Code incorrect.", "error")
            return redirect(url_for("verify"))
    return render_template("verify.html")

@app.route("/logout")
def logout():
    session.clear()
    global unlocked
    unlocked = False
    flash("Déconnecté.", "info")
    return redirect(url_for("landing"))

@app.route("/dashboard")
def dashboard():
    if not is_logged_in():
        return redirect(url_for("verify"))
    with rec_lock:
        rec = recording
    return render_template("dashboard.html", armed=armed, recording=rec)

@app.route("/photo", methods=["POST"])
def r_photo():
    if not is_logged_in(): 
        return redirect(url_for("verify"))
    p = take_photo()
    if p:
        flash("Photo prise.", "success")
        # DEMANDE: ne pas envoyer la photo sur Discord depuis l’interface.
        # (Suppression de: send_discord_file(p, "📸 Photo prise depuis le tableau de bord."))
    else:
        flash("Erreur photo.", "error")
    return redirect(url_for("dashboard"))

# Autoriser GET pour éviter erreurs si on clique l'URL directement
@app.route("/toggle_rec", methods=["POST", "GET"])
def r_toggle_rec():
    if not is_logged_in(): 
        return redirect(url_for("verify"))
    try:
        with rec_lock:
            rec = recording
        if rec:
            stop_recording() 
            flash("Enregistrement arrêté.", "info")
        else:
            start_recording()
            flash("Enregistrement démarré.", "success")
    except Exception as e:
        log_event(f"/toggle_rec error: {e}")
        flash("Erreur bascule enregistrement.", "error")
    # Redirection pour fermer proprement la connexion HTTP
    return redirect(url_for("dashboard"))

@app.route("/beep", methods=["POST"])
def r_beep():
    if not is_logged_in(): 
        return redirect(url_for("verify"))
    threading.Thread(target=buz_beep, args=("triple",), daemon=True).start()
    return redirect(url_for("dashboard"))

@app.route("/toggle_arm", methods=["POST"])
def r_toggle_arm():
    if not is_logged_in(): 
        return redirect(url_for("verify"))
    global armed
    armed = not armed
    flash(f"Alarme {'ARMÉE' if armed else 'DÉSARMÉE'}.", "success")
    return redirect(url_for("dashboard"))

@app.route("/status")
def r_status():
    with rec_lock:
        rec = recording
    return jsonify({
        "armed": armed,
        "recording": rec,
        "width": WIDTH, "height": HEIGHT, "fps": FPS,
        "last_events": events[-20:]
    })

# ----- RUN -----
def cleanup_and_exit(sig=None, frame=None):
    try: stop_recording()
    except: pass
    try: buz.off()
    except: pass
    try: release_camera()
    except: pass
    os._exit(0)

def run_web():
    # threaded=True permet à Flask de servir /toggle_rec pendant que la boucle caméra tourne
    app.run(host=WEB_BIND, port=WEB_PORT, debug=False, use_reloader=False, threaded=True)

if __name__ == "__main__":
    signal.signal(signal.SIGINT,  cleanup_and_exit)
    signal.signal(signal.SIGTERM, cleanup_and_exit)

    MEDIA_DIR.mkdir(exist_ok=True)
    init_camera()
    setup_button_callbacks()

    # Threads
    threading.Thread(target=cam_write_loop, daemon=True).start()
    threading.Thread(target=pir_watch_loop, daemon=True).start()
    threading.Thread(target=run_web, daemon=True).start()

    log_event(f"Service démarré. Web: http://{WEB_BIND}:{WEB_PORT}")
    log_event("Page vitrine: '/', accès caché -> '/verify'.")
    while True:
        time.sleep(1.0)
cmd